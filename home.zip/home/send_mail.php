<?php
require 'master/PHPMailerAutoload.php'; 
if(isset($_POST['send']))
        {
            $name=$_POST['name'];
            $mail=$_POST['email'];
            $dates=$_POST['dates'];
            $timing=$_POST['timing'];
            $mailto = $mail;
            $mailSub = "successfully Appointed...";
            $mailMsg = "Your Appoinrment is Registered,Enjoy Our Service.....".$name."<br>Appoitment-date:".$dates;
            $mail = new PHPMailer();
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "smtp.gmail.com";
            $mail ->Port = 465; // or 587
            $mail ->IsHTML(true);
            $mail ->Username = "pavi.harshit.gamer@gmail.com";

            $mail ->Password = "Pavi21696";
            $mail ->SetFrom("pavi.harshit.gamer@gmail.com");
            $mail ->Subject = $mailSub;
            $mail ->Body = $mailMsg;
            $mail ->AddAddress($mailto);

            if($mail->Send())
             {
                 echo "<script>";
                 echo "alert('Mail Sent successfully....');";
                 echo "window.location.href='index.php';</script>";
             }
            else
             {
                  echo "<script>";
                 echo "alert('Mail not Sent successfully....');";
                 echo "window.location.href='mail.html';</script>";              
             }
                    
         }

      else
      {
          echo "<script>alert('There is an error in the  form...');window.location.href=`index.php`;</script>";
          
      }
   
    

?>


   

