<?php include('functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system PHP and MySQL</title>
	
		<meta charset="utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- STYLE CSS -->	
		<link rel="stylesheet" href="css1/style.css">
	</head>
<body bgcolor="lightpink">

	<div class="wrapper">
			<div class="inner">
				<div class="image-holder">
					<img src="images1/registration-form-4.jpg" alt="">
				</div>
	
	<form method="post" action="login.php">

		<?php echo display_error(); ?>

		<h3>Login</h3>
					<div class="form-holder active">
						<input type="text" placeholder="name" class="form-control" name="username">
					</div>
					<div class="form-holder active">
						<input type="password" placeholder="password"  class="form-control" name="password">
					</div>


		
	
		<div class="form-holder">
			<button type="submit" class="btn" name="login_btn">Login</button>
		</div><br><br>
		<p><font size="3px">
			Not yet a member? <a href="register.php">Sign up</a>
	</font>
		</p>
	</form>


</body>
</html>