<?php
   
   $email = "";
  
   $service = "";
   $comment = "";
   $errors1 = array();

// connect to the database
//$conn= mysqli_connect('localhost','root');
//mysqli_select_db($conn,"reg1");
$db = mysqli_connect('localhost','root','','demo1');
//ifregister  button is clicked
if(isset($_POST['feed'])){
	
	
	$email=mysqli_real_escape_string($db, $_POST['email']);
    
	//$password_1=mysqli_real_escape_string($db, $_POST['password_1']);
	//$password_2=mysqli_real_escape_string($db, $_POST['password_2']);
	$service=mysqli_real_escape_string($db, $_POST['service']);
	$comment=mysqli_real_escape_string($db, $_POST['comment']);
	//$off=mysqli_real_escape_string($db, $_POST['off']);
   // $dates=mysqli_real_escape_string($db, $_POST['dates']);


	   //ensure  that form fields are filled properely
	
	if(empty($email)){
		array_push($errors1, "Email is required");
	}
	
	if(empty($service)){
		array_push($errors1, "Please Rate our service");
	}
	if(empty($comment)){
		array_push($errors1, "Please Post your Commant");
	}
	

	
   // if there are no error,save user to database
     if(count($errors1) == 0){
     	//$password = md5($password_1);  //encrypt password before storing in database(security) 
     	$sql = "INSERT INTO feed(email,service,comment)
     	VALUES('$email','$service','$comment')";
     	mysqli_query($db,$sql);
     }

} 
?>