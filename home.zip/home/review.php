<?php
$conn=mysqli_connect("localhost","root","","demo1");
session_start();
$sql="SELECT * FROM feed";
$records=mysqli_query($conn,$sql);
?>
s
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		div{
			border-radius: 50px;
			background-color: #b4b4b4;
			padding: 50px;
			margin: 75px;
			margin-left: 270px;
			font-size: 20px;
			width: 50%;
			font-family: sans-serif;		}
			td{
				padding: 10px;
				padding-left: 40px;
			}

		.d{
			background-color: #333;
			color: white;
			padding: 5px;
			width: 55%;	
			margin-left: 270px;
			text-align: center;
			font-family: sans-serif;

		}
		.button {
    
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 21px;
    float:right;
    cursor: pointer;
}
.button:hover {
      background-color: #008CBA;
      color: white;
 }
.button:active {
  background-color: black;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
		
		
		
		
		

	</style>
	
</head>
<body style="background-image: linear-gradient(-90deg,violet,blue)">
	<a href="index.php" class="button"><b>Back</b></a><br>

	<div class="d">
		<h1>Feedback Review's</h1>
	</div>
	
<?php
while($feed=mysqli_fetch_assoc($records)){

	
	echo "<div>";
	echo "<table>";
	

	echo "<tr><td><b>Email<b></td><td>:</td><td>".$feed['email']."</td></tr>";

	echo "<tr><td><b>Service<b></td><td>:</td><td>".$feed['service']."</td></tr>";
	echo "<tr><td><b>Comment<b></td><td>:</td><td>".$feed['comment']."</td></tr>";
	echo "</table>"; 
	
		
	
	echo "</div>";
}

	
?>


</body>
</html>