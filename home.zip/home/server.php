<?php
   $username = "";
   $birthday = "";
   $gender = "";
   $email = "";
   $address = "";
   $phone = "";
   $off = "";
   $dates = "";
   $timing = "";
   $errors = array();

// connect to the database
//$conn= mysqli_connect('localhost','root');
//mysqli_select_db($conn,"reg1");
$db = mysqli_connect('localhost','root','','demo1');
//ifregister  button is clicked
if(isset($_POST['appoin'])){
	
	$username=mysqli_real_escape_string($db, $_POST['username']);
	$birthday=mysqli_real_escape_string($db, $_POST['birthday']);
	$gender=mysqli_real_escape_string($db, $_POST['gender']);

	$email=mysqli_real_escape_string($db, $_POST['email']);
	//$password_1=mysqli_real_escape_string($db, $_POST['password_1']);
	//$password_2=mysqli_real_escape_string($db, $_POST['password_2']);
	$address=mysqli_real_escape_string($db, $_POST['address']);
	$phone=mysqli_real_escape_string($db, $_POST['phone']);
	$off=mysqli_real_escape_string($db, $_POST['off']);
    $dates=mysqli_real_escape_string($db, $_POST['dates']);
    $timing=mysqli_real_escape_string($db, $_POST['timing']);

	   //ensure  that form fields are filled properely
	if(empty($username)){
		array_push($errors, "User name is required");
	}
	if(empty($birthday)){
		array_push($errors, "birthday date is required");
	}
	if(empty($gender)){
         array_push($errors, "Gender is required");
	}
	if(empty($email)){
		array_push($errors, "Email is required");
	}elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		array_push($errors, "Invalid Email address");
	}
	if(empty($address)){
		array_push($errors, "address is required");
	}
	if(empty($phone)){
		array_push($errors, "Phone Number is required");
	}elseif(!preg_match('/^[0-9]{10}+$/', $_POST['phone'])) {
		array_push($errors, "Invalid Phone Number");
	}
	if(empty($off)){
		array_push($errors, "Offer field is required");
	}
	if(empty($dates)){
		array_push($errors, "Appoinment date  is required");
	}
	if(empty($timing)){
		array_push($errors, "Appoinment time is required");
	}

	
   // if there are no error,save user to database
     if(count($errors) == 0){
     	//$password = md5($password_1);  //encrypt password before storing in database(security) 
     	$sql = "INSERT INTO appoin(username,birthday,gender,email,address,phone,off,dates,timing)
     	VALUES('$username','$birthday','$gender','$email','$address','$phone','$off','$dates','$timing')";
     	mysqli_query($db,$sql);
     }

} 
?>